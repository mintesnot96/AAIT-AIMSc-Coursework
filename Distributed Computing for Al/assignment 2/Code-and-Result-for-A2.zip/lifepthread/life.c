#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#include <string.h>

#define MATCH(s) (!strcmp(argv[ac], (s)))

#include "pthread.h"
pthread_barrier_t barr;

int MeshPlot(int t, int m, int n, char **mesh);


void *parllelWorkMapUpate(void *args);
void outputResult(char**, char*, int, int);
void resultVerifier(char**, char*, int, int);

double real_rand();
int seed_rand(long sd);

static char **currWorld=NULL, **nextWorld=NULL, **tmesh=NULL;
static int maxiter = 200; /* number of iteration timesteps */
static int population[2] = {0,0}; /* number of live cells */

int nx = 100;      /* number of mesh points in the x dimension */
int ny = 100;      /* number of mesh points in the y dimension */

static int w_update = 0;
static int w_plot = 1;

double getTime();
extern FILE *gnu;

struct localThreadData{
    int threadID;
    long maxiter;
    int numberOfThreads;
    int disable_display;
    int s_step;
};
void serialWorkMapUpdate(int disable_display) {
    for (int t = 0; t < maxiter && population[w_plot]; t++) {
        // Perform cell updates serially
        for (int i = 1; i < nx - 1; i++) {
            for (int j = 1; j < ny - 1; j++) {
                int nn = currWorld[i+1][j] + currWorld[i-1][j] +
                         currWorld[i][j+1] + currWorld[i][j-1] +
                         currWorld[i+1][j+1] + currWorld[i-1][j-1] +
                         currWorld[i-1][j+1] + currWorld[i+1][j-1];
                nextWorld[i][j] = currWorld[i][j] ? (nn == 2 || nn == 3) : (nn == 3);
            }
        }
        // Swap pointers
        tmesh = nextWorld;
        nextWorld = currWorld;
        currWorld = tmesh;

        // Plot if enabled
        if (!disable_display) {
            MeshPlot(t, nx, ny, currWorld);
        }
    }
}

int main(int argc,char **argv)
{
    int i,j,ac;

    /* Set default input parameters */

    float prob = 0.5;   /* Probability of placing a cell */
    long seedVal = 0;
    int game = 0;
    int s_step = 0;
    int numthreads = 1;
    int disable_display= 0;

    /* Over-ride with command-line input parameters (if any) */

    for(ac=1;ac<argc;ac++)
    {
        if(MATCH("-n")) {nx = atoi(argv[++ac]);}
        else if(MATCH("-i")) {maxiter = atoi(argv[++ac]);}
        else if(MATCH("-t"))  {numthreads = atof(argv[++ac]);}
        else if(MATCH("-p"))  {prob = atof(argv[++ac]);}
        else if(MATCH("-s"))  {seedVal = atof(argv[++ac]);}
        else if(MATCH("-step"))  {s_step = 1;}
        else if(MATCH("-d"))  {disable_display = 1;}
        else if(MATCH("-g"))  {game = atoi(argv[++ac]);}
        else {
            printf("Usage: %s [-n < meshpoints>] [-i <iterations>] [-s seed] [-p prob] [-t numthreads] [-step] [-g <game #>] [-d]\n",argv[0]);
            return(-1);
        }
    }

    int rs = seed_rand(seedVal);
    /* Increment sizes to account for boundary ghost cells */

    nx = nx+2;
    ny = nx;

    /* Allocate contiguous memory for two 2D arrays of size nx*ny.
     * Two arrays are required because in-place updates are not
     * possible with the simple iterative scheme listed below */

    currWorld = (char**)malloc(sizeof(char*)*nx + sizeof(char)*nx*ny);
    for(i=0;i<nx;i++)
        currWorld[i] = (char*)(currWorld+nx) + i*ny;

    nextWorld = (char**)malloc(sizeof(char*)*nx + sizeof(char)*nx*ny);
    for(i=0;i<nx;i++)
        nextWorld[i] = (char*)(nextWorld+nx) + i*ny;

    /* Set the boundary ghost cells to hold 'zero' */
    for(i=0;i<nx;i++)
    {
        currWorld[i][0]=0;
        currWorld[i][ny-1]=0;
        nextWorld[i][0]=0;
        nextWorld[i][ny-1]=0;
    }
    for(i=0;i<ny;i++)
    {
        currWorld[0][i]=0;
        currWorld[nx-1][i]=0;
        nextWorld[0][i]=0;
        nextWorld[nx-1][i]=0;
    }

    // Generate a world

    if (game == 0){ // Use Random input
        for(i=1;i<nx-1;i++)
            for(j=1;j<ny-1;j++) {
                currWorld[i][j] = (real_rand() < prob);
                population[w_plot] += currWorld[i][j];
            }
    }
    else if (game == 1){ //  Block, still life
        printf("2x2 Block, still life\n");
        int nx2 = nx/2;
        int ny2 = ny/2;
        currWorld[nx2+1][ny2+1] = currWorld[nx2][ny2+1] = currWorld[nx2+1][ny2] = currWorld[nx2][ny2] = 1;
        population[w_plot] = 4;
    }
    else if (game == 2){ //  Glider (spaceship)
        printf("Glider (spaceship)\n");
        // Your code codes here
        currWorld[2][1] = currWorld[3][2] = currWorld[1][3] = currWorld[2][3] = currWorld[3][3] = 1;
        population[w_plot] = 5;
    }
    else{
        printf("Unknown game %d\n",game);
        exit(-1);
    }

    printf("probability: %f\n",prob);
    printf("Random # generator seed: %d\n", rs);

    /* Plot the initial data */
    if(!disable_display)
        MeshPlot(0,nx,ny,currWorld);

    /* Perform updates for maxiter iterations */
    double t0 = getTime();
    int t;
    // first we have to check if Whether the input is one thread or not
    // if it is, we have to ignore pthread implementation, just use serial implementation
    if (numthreads == 1) {
        // So we run serial implementation function declared earlier, Run the simulation serially
        serialWorkMapUpdate(disable_display);
    } else {

    // Task Parallelism: Initialize and create threads for different tasks
    // The main function sets up multithreading, where one thread is dedicated to graphical display (plotter thread)
    // and the others are responsible for performing the cell updates. This illustrates task parallelism, where different
    // tasks (display and computation) are handled concurrently by separate threads. The use of pthreads allows for
    // efficient parallel execution of these distinct tasks. The barrier synchronization ensures that all threads
    // reach a common point before proceeding, crucial for maintaining consistent state across iterations.

        int numberOfThreads = numthreads;
        pthread_t threads[numberOfThreads];
        pthread_attr_t attr;
        pthread_attr_init(&attr);
        pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
        struct localThreadData localThreadDataArray[numberOfThreads];
        pthread_barrier_init(&barr, NULL, (unsigned) numberOfThreads);

        int rc;
        long tz;

        /*Saving parameters to be passed to threads, and creation of the threads */
        for (tz = 0; tz < numberOfThreads; tz++) {
            localThreadDataArray[tz].threadID = tz;
            localThreadDataArray[tz].maxiter = maxiter;
            localThreadDataArray[tz].numberOfThreads = numberOfThreads;
            localThreadDataArray[tz].disable_display = disable_display;
            localThreadDataArray[tz].s_step = s_step;
            rc = pthread_create(&threads[tz], &attr, parllelWorkMapUpate, (void *) &localThreadDataArray[tz]);
            if (rc) {
                printf("ERROR; return code from pthread_create() #%ld is %d\n", tz, rc);
                exit(-1);
            }
        }

        pthread_attr_destroy(&attr);
        for (tz = 0; tz < numberOfThreads; tz++) {
            rc = pthread_join(threads[tz], NULL);
            if (rc) {
                printf("ERROR; return code from pthread_join() is %d\n", rc);
                exit(-1);
            }
        }

        pthread_barrier_destroy(&barr);
    }
    double t1 = getTime();
    printf("Running time for the iterations: %f sec.\n",t1-t0);
    printf("Press enter to end.\n");
    getchar();

    if(gnu != NULL)
        pclose(gnu);

    /* Free resources */
    free(nextWorld);
    free(currWorld);

    return(0);

}

void *parllelWorkMapUpate(void *args){
    struct localThreadData *localArgs = (struct localThreadData *) args;
    int threadID = localArgs->threadID;
    long maxiter = localArgs->maxiter;
    int numberOfThreads = localArgs->numberOfThreads;
    int disable_display = localArgs->disable_display;
    int s_step = localArgs->s_step;

    // Data Parallelism: Divide and conquer approach for cell updates
    // This function demonstrates data parallelism by dividing the computation domain (game board) among multiple threads.
    // Each thread computes a specific part of the game board, allowing for concurrent processing and efficient use of resources.
    // The domain is divided approximately equally among the threads to balance the workload. Special handling is implemented
    // to manage cases where the number of threads does not divide the mesh size evenly. The barrier at the end of each iteration
    // ensures all threads complete their tasks before the next iteration starts, maintaining data consistency across the game board.
    //In the case the numberOfThreads is 1, make sure no divide by zero error
    int itemsPerTask = (numberOfThreads == 1) ? nx - 2 : (nx - 2)/(numberOfThreads - 1);
    int startRow = (threadID - 1) * itemsPerTask + 1;
    /*All threads gets even amount of work, except last which gets slightly few more
      in the case that work is not evenly divisible */
    int endRow = (threadID - 1) < (numberOfThreads - 2) ? (threadID) * itemsPerTask + 1 : nx - 1;
    int t, i, j;
    //printf("startRow: %d, endRow %d \n", startRow, endRow);
    for(t=0;t<maxiter && population[w_plot];t++)
    {
        /*Need second part of conditional for edge case of only 1 thread */
        if(threadID != 0 || numberOfThreads == 1){
            /* Use currWorld to compute the updates and store it in nextWorld */
            for(i=startRow;i<endRow;i++)
                for(j=1;j<nx-1;j++) {
                    int nn = currWorld[i+1][j] + currWorld[i-1][j] +
                             currWorld[i][j+1] + currWorld[i][j-1] +
                             currWorld[i+1][j+1] + currWorld[i-1][j-1] +
                             currWorld[i-1][j+1] + currWorld[i+1][j-1];

                    nextWorld[i][j] = currWorld[i][j] ? (nn == 2 || nn == 3) : (nn == 3);
                }
        }
        pthread_barrier_wait(&barr);

        if(threadID == 0){
            /* Pointer Swap : nextWorld <-> currWorld */
            tmesh = nextWorld;
            nextWorld = currWorld;
            currWorld = tmesh;
        }

        if(threadID == 0){
            /* Start the new plot */
            if(!disable_display)
                MeshPlot(t,nx,ny,currWorld);

            if (s_step){
                printf("Finished with step %d\n",t);
                printf("Press enter to continue.\n");
                getchar();
            }
        }
    }
}
